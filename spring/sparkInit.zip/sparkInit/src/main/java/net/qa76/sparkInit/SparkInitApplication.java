package net.qa76.sparkInit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SparkInitApplication {

	public static void main(String[] args) {
		SpringApplication.run(SparkInitApplication.class, args);
	}

}
